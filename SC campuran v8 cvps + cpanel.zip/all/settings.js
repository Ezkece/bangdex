require("./module")

global.owner = "6285850213046"
global.ownerStore = "6285850213046"
global.namabot = "ZansBotz Offcial"
global.namaCreator = "ZansBotz Offcial"
global.namaStore = "ZansBotz Offcial"
global.autoJoin = false
global.antilink = false
global.themeemoji = '🪀'
global.versisc = '7.0.0'
global.namasc = 'Versi 8 Campuran Addpm2'
global.codeInvite = "-"
global.apitokendo = '-'
global.domain = '-' // Isi Domain Lu
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "-"
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.thumb = fs.readFileSync("./thumb.png")
global.audionya = fs.readFileSync("./all/sound.mp3")
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
global.packname = ""
global.author = "Sticker By Zans Official"
global.jumlah = "5"
global.youtube = "https://www.youtube.com/@ZansPiw"
global.grup = "https://chat.whatsapp.com/EGI9AnELtyL6uG36BYanyp"
global.telegram = "https://t.me/AdisDzaky"
global.instagram = "*Lom ada*"
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})